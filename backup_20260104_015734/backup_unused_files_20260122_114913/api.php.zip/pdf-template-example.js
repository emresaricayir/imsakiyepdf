/**
 * PDF Şablon Örneği
 * Bu dosya, PDF'e arka plan resmi veya özel tasarım ekleme örneğini gösterir
 */

// Örnek: Arka plan resmi ile PDF oluşturma
function generatePDFWithBackground() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
    });
    
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    
    // YÖNTEM 1: Arka plan resmi ekleme
    // Not: Resim dosyası public klasöründe olmalı (örn: images/background.jpg)
    const backgroundImage = 'images/imsakiye-background.jpg';
    
    // Arka plan resmini ekle (tüm sayfayı kaplayacak şekilde)
    doc.addImage(backgroundImage, 'JPEG', 0, 0, pageWidth, pageHeight, undefined, 'FAST');
    
    // Şimdi üzerine içeriği yazdır
    // ... (mevcut PDF oluşturma kodunuz)
}

// Örnek: Özel şablon ile PDF oluşturma
function generatePDFWithTemplate() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
    });
    
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    
    // YÖNTEM 2: Programatik olarak arka plan tasarımı oluşturma
    // Dekoratif çerçeve
    doc.setDrawColor(102, 126, 234);
    doc.setLineWidth(2);
    doc.rect(10, 10, pageWidth - 20, pageHeight - 20, 'S');
    
    // Dekoratif köşeler
    const cornerSize = 15;
    doc.setLineWidth(1);
    // Sol üst köşe
    doc.line(10, 10, 10 + cornerSize, 10);
    doc.line(10, 10, 10, 10 + cornerSize);
    // Sağ üst köşe
    doc.line(pageWidth - 10, 10, pageWidth - 10 - cornerSize, 10);
    doc.line(pageWidth - 10, 10, pageWidth - 10, 10 + cornerSize);
    // Sol alt köşe
    doc.line(10, pageHeight - 10, 10 + cornerSize, pageHeight - 10);
    doc.line(10, pageHeight - 10, 10, pageHeight - 10 - cornerSize);
    // Sağ alt köşe
    doc.line(pageWidth - 10, pageHeight - 10, pageWidth - 10 - cornerSize, pageHeight - 10);
    doc.line(pageWidth - 10, pageHeight - 10, pageWidth - 10, pageHeight - 10 - cornerSize);
    
    // Dekoratif başlık arka planı
    doc.setFillColor(102, 126, 234);
    doc.setGState(doc.GState({opacity: 0.1})); // Şeffaflık
    doc.rect(10, 10, pageWidth - 20, 30, 'F');
    
    // Şimdi üzerine içeriği yazdır
    // ... (mevcut PDF oluşturma kodunuz)
}

// YÖNTEM 3: HTML/CSS şablonunu PDF'e dönüştürme (html2canvas + jsPDF)
// Bu yöntem için html2canvas kütüphanesi gerekir
async function generatePDFFromHTMLTemplate() {
    // html2canvas kütüphanesini yükle (CDN'den)
    if (typeof html2canvas === 'undefined') {
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
        document.head.appendChild(script);
        await new Promise(resolve => script.onload = resolve);
    }
    
    // HTML elementini seç (örneğin özel bir div)
    const element = document.getElementById('imsakiye-container');
    
    // HTML'i canvas'a dönüştür
    const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff'
    });
    
    // Canvas'ı resim olarak al
    const imgData = canvas.toDataURL('image/png');
    
    // PDF oluştur
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
    });
    
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * pageWidth) / canvas.width;
    
    // Resmi PDF'e ekle
    doc.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
    
    // PDF'i indir
    doc.save('imsakiye-with-template.pdf');
}

